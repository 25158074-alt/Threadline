import { db } from "@/db";
import { decisions, meetings } from "@/db/schema";
import { sql } from "drizzle-orm";
import { computeStatus } from "@/lib/status";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const STOP_WORDS = new Set([
  "why", "did", "we", "decide", "decided", "decision", "do", "what", "the",
  "and", "or", "of", "to", "a", "an", "for", "on", "in", "at", "about",
  "who", "what", "when", "how", "that", "this", "with", "it", "is", "are",
]);

function tokens(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2 && !STOP_WORDS.has(t));
}

// rank decisions by keyword overlap with the question
export async function POST(req: Request) {
  const body = await req.json();
  const question = String(body.question || "").trim();

  if (!question) {
    return NextResponse.json({ error: "Ask a question.", results: [] }, { status: 400 });
  }

  const all = await db
    .select({
      decision: decisions,
      meetingTitle: meetings.title,
      meetingSource: meetings.source,
    })
    .from(decisions)
    .leftJoin(meetings, sql`${meetings.id} = ${decisions.meetingId}`);

  const qTokens = tokens(question);

  const scored = all
    .map((row) => {
      const d = row.decision;
      const haystack =
        (d.decision + " " + (d.reasoning || "") + " " + (d.owner || "") + " " + row.meetingTitle).toLowerCase();
      let score = 0;
      for (const t of qTokens) {
        if (haystack.includes(t)) score += 1;
      }
      return { ...row, score };
    })
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 8)
    .map((r) => ({
      ...r.decision,
      meetingTitle: r.meetingTitle,
      currentStatus: computeStatus(r.decision.deadlineDate, r.decision.status),
    }));

  return NextResponse.json({ results: scored });
}
