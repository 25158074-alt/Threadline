import { db } from "@/db";
import { meetings, decisions } from "@/db/schema";
import { extractDecisions } from "@/lib/extract";
import { computeStatus } from "@/lib/status";
import { eq, desc } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const meetingRows = await db
    .select()
    .from(meetings)
    .orderBy(desc(meetings.createdAt));

  const withCounts = await Promise.all(
    meetingRows.map(async (m) => {
      const decs = await db
        .select()
        .from(decisions)
        .where(eq(decisions.meetingId, m.id));
      const done = decs.filter((d) => d.status === "resolved").length;
      return {
        ...m,
        decisionCount: decs.length,
        doneCount: done,
      };
    })
  );

  return NextResponse.json(withCounts);
}

export async function POST(req: Request) {
  const body = await req.json();
  const title = String(body.title || "Untitled Meeting").trim();
  const rawNote = String(body.rawNote || "").trim();
  const source = String(body.source || "manual").trim();

  if (!rawNote) {
    return NextResponse.json({ error: "Meeting notes are required." }, { status: 400 });
  }

  const result = extractDecisions(rawNote);
  const meetingTitle = title || (result.summary ? result.summary : "Untitled Meeting");

  const [meeting] = await db
    .insert(meetings)
    .values({ title: meetingTitle, rawNote, source })
    .returning();

  for (const d of result.decisions) {
    const status = computeStatus(d.deadlineDate, "pending");
    await db.insert(decisions).values({
      meetingId: meeting.id,
      decision: d.decision,
      owner: d.owner,
      deadline: d.deadline,
      deadlineDate: d.deadlineDate,
      reasoning: d.reasoning,
      status,
    });
  }

  return NextResponse.json(
    { meeting, extractedCount: result.decisions.length },
    { status: 201 }
  );
}
