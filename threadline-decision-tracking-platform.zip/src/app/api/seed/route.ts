import { db } from "@/db";
import { meetings, decisions } from "@/db/schema";
import { NextResponse } from "next/server";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const SEED_MEETINGS = [
  {
    title: "Q3 Product Roadmap Sync",
    source: "manual",
    rawNote:
      "We decided to delay the mobile app relaunch to December because the redesign isn't ready. Emma owns the rollout. Deadline is end of week. We agreed to open source the analytics SDK by next month since it will speed up community adoption. Owner is Michael.",
  },
  {
    title: "Design System Kickoff",
    source: "transcript",
    rawNote:
      "Decision: adopt the existing component library as our single source of truth. The rationale is that we already maintain 40+ components. Priya owns it and will deliver the migration plan by Friday. We also decided to deprecate the legacy CSS framework because it causes accessibility issues.",
  },
  {
    title: "Vendor Review - CRM",
    source: "chat",
    rawNote:
      "We decided to renew the CRM contract for one more year. Because the current team knows it well and switching is risky. Owner is Carlos. Deadline: end of month. Also decided to assign two engineers to the data migration. Owner is Dana, due by Q2.",
  },
];

export async function POST() {
  // Only seed if empty to avoid duplicates
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(meetings);

  if (count > 0) {
    return NextResponse.json({ ok: true, seeded: false, message: "Already has data" });
  }

  let inserted = 0;
  const { extractDecisions } = await import("@/lib/extract");
  const { computeStatus } = await import("@/lib/status");

  for (const m of SEED_MEETINGS) {
    const result = extractDecisions(m.rawNote);
    if (result.decisions.length === 0) continue;

    const [meeting] = await db
      .insert(meetings)
      .values({ title: m.title, rawNote: m.rawNote, source: m.source })
      .returning();

    for (const d of result.decisions) {
      const status = computeStatus(d.deadlineDate, "pending");
      await db.insert(decisions).values({
        meetingId: meeting.id,
        decision: d.decision,
        owner: d.owner,
        deadline: d.deadline,
        deadlineDate: d.deadlineDate,
        reasoning: d.reasoning,
        status,
      });
      inserted++;
    }
  }

  return NextResponse.json({ ok: true, seeded: true, inserted });
}
