import { db } from "@/db";
import { decisions } from "@/db/schema";
import { and, eq, desc } from "drizzle-orm";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const meetingId = searchParams.get("meetingId");
  const status = searchParams.get("status");

  let rows;
  if (meetingId) {
    const opts = eq(decisions.meetingId, Number(meetingId));
    rows = status
      ? await db.select().from(decisions).where(and(opts, eq(decisions.status, status))).orderBy(desc(decisions.createdAt))
      : await db.select().from(decisions).where(opts).orderBy(desc(decisions.createdAt));
  } else {
    rows = status
      ? await db.select().from(decisions).where(eq(decisions.status, status)).orderBy(desc(decisions.createdAt))
      : await db.select().from(decisions).orderBy(desc(decisions.createdAt));
  }

  return NextResponse.json(rows);
}
