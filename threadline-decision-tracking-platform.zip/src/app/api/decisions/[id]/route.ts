import { db } from "@/db";
import { decisions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { computeStatus } from "@/lib/status";
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json();
  const numericId = Number(id);

  const existing = await db
    .select()
    .from(decisions)
    .where(eq(decisions.id, numericId));

  if (!existing.length) {
    return NextResponse.json({ error: "Decision not found" }, { status: 404 });
  }

  const current = existing[0];

  const updates: Record<string, unknown> = {};
  if (typeof body.status === "string") updates.status = body.status;
  if (typeof body.owner === "string") updates.owner = body.owner;

  if (typeof body.deadlineDate === "string" || body.deadlineDate === null) {
    updates.deadlineDate = body.deadlineDate ? new Date(body.deadlineDate) : null;
    updates.deadline = body.deadlineLabel ?? current.deadline;
  }

  // Recompute status if the stored status is not "resolved" (recalculate overdue/pending)
  if (updates.status !== "resolved") {
    const nextStatus = computeStatus(
      (updates.deadlineDate as Date | null) ?? current.deadlineDate,
      (updates.status as string) ?? current.status
    );
    updates.status = nextStatus;
  }

  const [updated] = await db
    .update(decisions)
    .set(updates)
    .where(eq(decisions.id, numericId))
    .returning();

  return NextResponse.json(updated);
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.delete(decisions).where(eq(decisions.id, Number(id)));
  return NextResponse.json({ ok: true });
}
