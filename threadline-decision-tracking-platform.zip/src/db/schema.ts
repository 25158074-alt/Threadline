import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  index,
} from "drizzle-orm/pg-core";

// A meeting / pasted transcript that produced decisions
export const meetings = pgTable(
  "meetings",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    rawNote: text("raw_note").notNull(),
    source: text("source").notNull().default("manual"), // manual | transcript | chat
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("meetings_created_idx").on(t.createdAt)]
);

// A single extracted decision tied to a meeting
export const decisions = pgTable(
  "decisions",
  {
    id: serial("id").primaryKey(),
    meetingId: integer("meeting_id")
      .notNull()
      .references(() => meetings.id, { onDelete: "cascade" }),
    decision: text("decision").notNull(),
    owner: text("owner"),
    deadline: text("deadline"),
    deadlineDate: timestamp("deadline_date"),
    reasoning: text("reasoning"),
    status: text("status").notNull().default("pending"), // pending | overdue | resolved
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("decisions_meeting_idx").on(t.meetingId),
    index("decisions_status_idx").on(t.status),
  ]
);
